package com.example.aula_01.recyclefatima;

import android.view.View;

public interface Click_Listener {

    void onClick(View view, int position);
}
